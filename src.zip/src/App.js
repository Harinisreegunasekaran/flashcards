import React from 'react';
import AlphabetFlashCard from './AlphabetFlashCard';
import './App.css';

function App() {
  return (
    <div className="App">
      <AlphabetFlashCard />
    </div>
  );
}

export default App;