import React, { useState } from 'react';

const AlphabetFlashCard = () => {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextCard = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % alphabet.length);
  };

  const prevCard = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex ===0 ? alphabet.length - 1 :prevIndex - 1);
  };

  return (
    <body>
    <div className="flash-card">
      <h1>ALPHABET FLASH CARD</h1>
      <div className="card">
        <h2>{alphabet[currentIndex]}</h2>
      </div>
      <div className="button-container">
        <button id="b1" onClick={prevCard}>Previous</button>
        <button id="b1" onClick={nextCard}>Next</button>
      </div>
      
    </div>
    <img src="https://i.pinimg.com/736x/93/a6/0c/93a60c9e085b2b9e3e9208766cf36ff8.jpg"></img>
    </body>
  );
};

export default AlphabetFlashCard;